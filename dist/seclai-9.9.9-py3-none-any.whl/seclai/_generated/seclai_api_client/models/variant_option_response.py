from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="VariantOptionResponse")


@_attrs_define
class VariantOptionResponse:
    """Response model for a variant option

    Attributes:
        default (bool):
        title (str):
        value (str):
        description (None | str | Unset):
        input_1h_cache_write_credits_per_1000_tokens (float | None | Unset):
        input_5m_cache_write_credits_per_1000_tokens (float | None | Unset):
        input_cache_hit_credits_per_1000_tokens (float | None | Unset):
        input_credits_per_1000_tokens (float | None | Unset):
        output_credits_per_1000_tokens (float | None | Unset):
    """

    default: bool
    title: str
    value: str
    description: None | str | Unset = UNSET
    input_1h_cache_write_credits_per_1000_tokens: float | None | Unset = UNSET
    input_5m_cache_write_credits_per_1000_tokens: float | None | Unset = UNSET
    input_cache_hit_credits_per_1000_tokens: float | None | Unset = UNSET
    input_credits_per_1000_tokens: float | None | Unset = UNSET
    output_credits_per_1000_tokens: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        default = self.default

        title = self.title

        value = self.value

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        input_1h_cache_write_credits_per_1000_tokens: float | None | Unset
        if isinstance(self.input_1h_cache_write_credits_per_1000_tokens, Unset):
            input_1h_cache_write_credits_per_1000_tokens = UNSET
        else:
            input_1h_cache_write_credits_per_1000_tokens = self.input_1h_cache_write_credits_per_1000_tokens

        input_5m_cache_write_credits_per_1000_tokens: float | None | Unset
        if isinstance(self.input_5m_cache_write_credits_per_1000_tokens, Unset):
            input_5m_cache_write_credits_per_1000_tokens = UNSET
        else:
            input_5m_cache_write_credits_per_1000_tokens = self.input_5m_cache_write_credits_per_1000_tokens

        input_cache_hit_credits_per_1000_tokens: float | None | Unset
        if isinstance(self.input_cache_hit_credits_per_1000_tokens, Unset):
            input_cache_hit_credits_per_1000_tokens = UNSET
        else:
            input_cache_hit_credits_per_1000_tokens = self.input_cache_hit_credits_per_1000_tokens

        input_credits_per_1000_tokens: float | None | Unset
        if isinstance(self.input_credits_per_1000_tokens, Unset):
            input_credits_per_1000_tokens = UNSET
        else:
            input_credits_per_1000_tokens = self.input_credits_per_1000_tokens

        output_credits_per_1000_tokens: float | None | Unset
        if isinstance(self.output_credits_per_1000_tokens, Unset):
            output_credits_per_1000_tokens = UNSET
        else:
            output_credits_per_1000_tokens = self.output_credits_per_1000_tokens

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "default": default,
                "title": title,
                "value": value,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if input_1h_cache_write_credits_per_1000_tokens is not UNSET:
            field_dict["input_1h_cache_write_credits_per_1000_tokens"] = input_1h_cache_write_credits_per_1000_tokens
        if input_5m_cache_write_credits_per_1000_tokens is not UNSET:
            field_dict["input_5m_cache_write_credits_per_1000_tokens"] = input_5m_cache_write_credits_per_1000_tokens
        if input_cache_hit_credits_per_1000_tokens is not UNSET:
            field_dict["input_cache_hit_credits_per_1000_tokens"] = input_cache_hit_credits_per_1000_tokens
        if input_credits_per_1000_tokens is not UNSET:
            field_dict["input_credits_per_1000_tokens"] = input_credits_per_1000_tokens
        if output_credits_per_1000_tokens is not UNSET:
            field_dict["output_credits_per_1000_tokens"] = output_credits_per_1000_tokens

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        default = d.pop("default")

        title = d.pop("title")

        value = d.pop("value")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_input_1h_cache_write_credits_per_1000_tokens(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        input_1h_cache_write_credits_per_1000_tokens = _parse_input_1h_cache_write_credits_per_1000_tokens(
            d.pop("input_1h_cache_write_credits_per_1000_tokens", UNSET)
        )

        def _parse_input_5m_cache_write_credits_per_1000_tokens(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        input_5m_cache_write_credits_per_1000_tokens = _parse_input_5m_cache_write_credits_per_1000_tokens(
            d.pop("input_5m_cache_write_credits_per_1000_tokens", UNSET)
        )

        def _parse_input_cache_hit_credits_per_1000_tokens(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        input_cache_hit_credits_per_1000_tokens = _parse_input_cache_hit_credits_per_1000_tokens(
            d.pop("input_cache_hit_credits_per_1000_tokens", UNSET)
        )

        def _parse_input_credits_per_1000_tokens(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        input_credits_per_1000_tokens = _parse_input_credits_per_1000_tokens(
            d.pop("input_credits_per_1000_tokens", UNSET)
        )

        def _parse_output_credits_per_1000_tokens(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        output_credits_per_1000_tokens = _parse_output_credits_per_1000_tokens(
            d.pop("output_credits_per_1000_tokens", UNSET)
        )

        variant_option_response = cls(
            default=default,
            title=title,
            value=value,
            description=description,
            input_1h_cache_write_credits_per_1000_tokens=input_1h_cache_write_credits_per_1000_tokens,
            input_5m_cache_write_credits_per_1000_tokens=input_5m_cache_write_credits_per_1000_tokens,
            input_cache_hit_credits_per_1000_tokens=input_cache_hit_credits_per_1000_tokens,
            input_credits_per_1000_tokens=input_credits_per_1000_tokens,
            output_credits_per_1000_tokens=output_credits_per_1000_tokens,
        )

        variant_option_response.additional_properties = d
        return variant_option_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
